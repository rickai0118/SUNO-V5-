
import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, X, Music, Activity, Monitor, Volume2, ChevronDown } from 'lucide-react';
import { getTranslation } from '../utils/translations';
import { Language } from '../types';

interface AudioPlayerProps {
  src: string;
  fileName: string;
  onRemove: () => void;
  statusLabel: string; 
  language?: Language;
}

type VisualizerMode = 'nebula' | 'grid' | 'tunnel' | 'matrix' | 'mist' | 'retro' | 'scope' | 'hex' | 'fire';

const AudioPlayer: React.FC<AudioPlayerProps> = ({ src, fileName, onRemove, statusLabel, language = 'en' as Language }) => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const animationRef = useRef<number>();
  const mistParticlesRef = useRef<any[]>([]); // Store particle state for Mist mode

  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [visualMode, setVisualMode] = useState<VisualizerMode>('nebula');
  const t = getTranslation(language);

  // Initialize Audio Context & Analyser
  useEffect(() => {
    if (!audioRef.current) return;

    if (!audioContextRef.current) {
        const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
        audioContextRef.current = new AudioContext();
        analyserRef.current = audioContextRef.current.createAnalyser();
        // Increased FFT size for better bass resolution (2048 = 1024 bins)
        analyserRef.current.fftSize = 2048; 
        analyserRef.current.smoothingTimeConstant = 0.8;
        
        // Connect nodes
        try {
            sourceRef.current = audioContextRef.current.createMediaElementSource(audioRef.current);
            sourceRef.current.connect(analyserRef.current);
            analyserRef.current.connect(audioContextRef.current.destination);
        } catch (e) {
            // MediaElementSource might already be connected if component re-renders, which is fine.
        }
    }

    return () => {
        // Context cleanup is usually handled by the browser, we keep it alive for performance
    }
  }, [src]);

  // Handle Play/Pause & Resume Context
  useEffect(() => {
      if(isPlaying && audioContextRef.current?.state === 'suspended') {
          audioContextRef.current.resume();
      }
      
      if (isPlaying) {
          startVisualizer();
      } else {
          cancelAnimationFrame(animationRef.current!);
      }
  }, [isPlaying, visualMode]);

  const startVisualizer = () => {
      if (!canvasRef.current || !analyserRef.current) return;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      const bufferLength = analyserRef.current.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const render = () => {
          animationRef.current = requestAnimationFrame(render);
          
          // Switch data type based on mode
          if (visualMode === 'scope') {
              analyserRef.current!.getByteTimeDomainData(dataArray);
          } else {
              analyserRef.current!.getByteFrequencyData(dataArray);
          }

          // Clear
          ctx.fillStyle = '#09090b';
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          switch (visualMode) {
              case 'nebula': drawNebula(ctx, canvas.width, canvas.height, dataArray, bufferLength); break;
              case 'grid': drawGrid(ctx, canvas.width, canvas.height, dataArray, bufferLength); break;
              case 'tunnel': drawTunnel(ctx, canvas.width, canvas.height, dataArray, bufferLength); break;
              case 'matrix': drawMatrix(ctx, canvas.width, canvas.height, dataArray, bufferLength); break;
              case 'mist': drawMist(ctx, canvas.width, canvas.height, dataArray, bufferLength); break;
              case 'retro': drawRetro(ctx, canvas.width, canvas.height, dataArray, bufferLength); break;
              case 'scope': drawScope(ctx, canvas.width, canvas.height, dataArray, bufferLength); break;
              case 'hex': drawHex(ctx, canvas.width, canvas.height, dataArray, bufferLength); break;
              case 'fire': drawFire(ctx, canvas.width, canvas.height, dataArray, bufferLength); break;
          }
      };
      render();
  }

  // --- Visualizer Engines ---
  const getAverageVolume = (data: Uint8Array, start: number, end: number) => {
      let sum = 0;
      for(let i = start; i < end; i++) {
          sum += data[i];
      }
      return sum / (end - start);
  }

  const drawNebula = (ctx: CanvasRenderingContext2D, w: number, h: number, data: Uint8Array, len: number) => {
      const cx = w / 2;
      const cy = h / 2;
      const bass = getAverageVolume(data, 1, 6); 
      const scale = 1 + (bass / 255) * 0.8;

      const gradient = ctx.createRadialGradient(cx, cy, 10 * scale, cx, cy, 150 * scale);
      gradient.addColorStop(0, `rgba(245, 158, 11, ${0.8 + (bass/255)*0.2})`);
      gradient.addColorStop(0.5, 'rgba(245, 158, 11, 0.2)');
      gradient.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(cx, cy, 200, 0, Math.PI * 2);
      ctx.fill();

      const step = Math.floor(len / 50);
      for(let i=0; i<50; i++) {
          const index = i * step;
          const val = data[index];
          const angle = (i / 50) * Math.PI * 2 + (Date.now() * 0.0005);
          const r = 50 + (val * 0.8);
          const px = cx + Math.cos(angle) * r;
          const py = cy + Math.sin(angle) * r;

          ctx.fillStyle = `rgba(34, 211, 238, ${val/255})`;
          ctx.beginPath();
          ctx.arc(px, py, 2 + (val/255)*3, 0, Math.PI * 2);
          ctx.fill();
      }
  };

  const drawGrid = (ctx: CanvasRenderingContext2D, w: number, h: number, data: Uint8Array, len: number) => {
    const bass = getAverageVolume(data, 1, 10);
    const shake = (bass / 255) * 5;

    ctx.strokeStyle = 'rgba(236, 72, 153, 0.3)';
    ctx.lineWidth = 1;
    const time = Date.now() * 0.05;
    
    for(let x = 0; x <= w; x += 50) {
        ctx.beginPath();
        ctx.moveTo(w/2 + (Math.random()-0.5)*shake, h/2 + (Math.random()-0.5)*shake);
        ctx.lineTo(x, h);
        ctx.stroke();
    }

    for(let y = 0; y < h/2; y+=20) {
        const offset = (y + time + (bass/10)) % (h/2);
        const yPos = (h/2) + offset;
        const widthAtY = w * (offset / (h/2));
        const xStart = (w - widthAtY) / 2;
        
        ctx.beginPath();
        ctx.moveTo(0, yPos);
        ctx.lineTo(w, yPos);
        ctx.strokeStyle = `rgba(6, 182, 212, ${(offset/(h/2)) * 0.5})`;
        ctx.stroke();
    }

    const barCount = 32;
    const barWidth = w / barCount;
    const step = Math.floor(len / 2 / barCount);

    for(let i=0; i<barCount; i++) {
        const val = data[i * step];
        const height = (val / 255) * (h/2.5);
        ctx.fillStyle = `rgba(245, 158, 11, 0.9)`;
        ctx.fillRect(i * barWidth, (h/2) - height, barWidth - 2, height);
        ctx.fillStyle = `rgba(245, 158, 11, 0.2)`;
        ctx.fillRect(i * barWidth, (h/2), barWidth - 2, height * 0.5);
    }
  };

  const drawTunnel = (ctx: CanvasRenderingContext2D, w: number, h: number, data: Uint8Array, len: number) => {
      const cx = w / 2;
      const cy = h / 2;
      ctx.lineWidth = 2;
      const bass = getAverageVolume(data, 0, 5);

      for (let i = 0; i < 20; i++) {
          const val = data[i * 5];
          const offset = (Date.now() * 0.1 + i * 20) % 360;
          const radius = (i * 15) + (val * 0.1) + ((bass/255) * 20); 
          
          ctx.strokeStyle = `hsl(${offset}, 80%, 50%)`;
          ctx.beginPath();
          ctx.arc(cx, cy, Math.max(0, radius), 0, Math.PI * 2);
          ctx.stroke();
      }
  };

  const drawMatrix = (ctx: CanvasRenderingContext2D, w: number, h: number, data: Uint8Array, len: number) => {
      ctx.font = '12px monospace';
      const cols = Math.floor(w / 15);
      const step = Math.floor(len / cols);
      
      for (let i = 0; i < cols; i++) {
          const val = data[i * step];
          const height = (val / 255) * h;
          
          if (val > 50) {
            ctx.fillStyle = '#10b981';
            const char = String.fromCharCode(0x30A0 + (Math.random() * 96));
            ctx.fillText(char, i * 15, h - height + (Math.random() * 10));
            ctx.fillStyle = 'rgba(16, 185, 129, 0.1)';
            ctx.fillRect(i * 15, h - height, 12, height);
          }
      }
  };

  const drawMist = (ctx: CanvasRenderingContext2D, w: number, h: number, data: Uint8Array, len: number) => {
      if (mistParticlesRef.current.length === 0) {
          for (let i = 0; i < 30; i++) {
              mistParticlesRef.current.push({
                  x: Math.random() * w,
                  y: Math.random() * h,
                  vx: (Math.random() - 0.5) * 0.5,
                  vy: (Math.random() - 0.5) * 0.5,
                  r: 30 + Math.random() * 50
              });
          }
      }

      const bass = getAverageVolume(data, 1, 8); 
      const treble = getAverageVolume(data, 100, 300);

      mistParticlesRef.current.forEach(p => {
          p.x += p.vx + (bass/255)*0.5;
          p.y += p.vy;
          if (p.x < -100) p.x = w + 100;
          if (p.x > w + 100) p.x = -100;
          if (p.y < -100) p.y = h + 100;
          if (p.y > h + 100) p.y = -100;

          const pulse = (bass / 255) * 40;
          const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r + pulse);
          g.addColorStop(0, `rgba(88, 28, 135, 0.2)`); 
          g.addColorStop(1, 'rgba(0,0,0,0)');
          
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r + pulse, 0, Math.PI * 2);
          ctx.fill();
      });

      if (treble > 80) {
          const intensity = (treble - 80) / 100;
          ctx.strokeStyle = `rgba(255, 255, 255, ${intensity})`;
          ctx.shadowBlur = 15;
          ctx.shadowColor = '#22d3ee';
          ctx.lineWidth = 1 + intensity * 2;
          
          ctx.beginPath();
          const p1 = mistParticlesRef.current[Math.floor(Math.random() * mistParticlesRef.current.length)];
          const p2 = mistParticlesRef.current[Math.floor(Math.random() * mistParticlesRef.current.length)];
          
          ctx.moveTo(p1.x, p1.y);
          const segments = 6;
          let cx = p1.x;
          let cy = p1.y;
          const dx = (p2.x - p1.x) / segments;
          const dy = (p2.y - p1.y) / segments;

          for(let i=1; i<segments; i++) {
              cx += dx;
              cy += dy;
              const jitter = (Math.random() - 0.5) * 50 * intensity;
              ctx.lineTo(cx + jitter, cy + jitter);
          }
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
          ctx.shadowBlur = 0;
      }
  };

  const drawRetro = (ctx: CanvasRenderingContext2D, w: number, h: number, data: Uint8Array, len: number) => {
      // 1. Sun
      const bass = getAverageVolume(data, 1, 10);
      const sunY = h * 0.6;
      const sunR = 80 + (bass / 255) * 20;

      const g = ctx.createLinearGradient(0, sunY - sunR, 0, sunY + sunR);
      g.addColorStop(0, '#fde047'); // Yellow
      g.addColorStop(0.5, '#f97316'); // Orange
      g.addColorStop(1, '#ec4899'); // Pink
      
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(w/2, sunY, sunR, 0, Math.PI * 2);
      ctx.fill();

      // Sun Bands
      const time = Date.now() * 0.02;
      ctx.fillStyle = '#09090b'; // Background color cuts
      for(let i=0; i<8; i++) {
          const bandH = 4 + i * 2;
          const y = (sunY + sunR*0.2) + ((time + i * 20) % (sunR * 1.5));
          if(y < sunY + sunR) {
              ctx.fillRect(w/2 - sunR, y, sunR*2, bandH);
          }
      }

      // 2. Horizon Grid
      const horizonY = sunY + sunR * 0.5;
      ctx.fillStyle = '#09090b';
      ctx.fillRect(0, horizonY, w, h - horizonY); // Ground
      
      ctx.strokeStyle = '#a855f7'; // Purple grid
      ctx.lineWidth = 2;
      ctx.beginPath();
      // Moving horizontal lines
      const speed = Date.now() * 0.1 + (bass * 0.1);
      for(let i=0; i<10; i++) {
           const p = (i * 30 + speed) % 200;
           // Exponential distance for perspective
           const y = horizonY + (p*p)/100;
           if(y < h) {
               ctx.moveTo(0, y);
               ctx.lineTo(w, y);
           }
      }
      // Vertical lines fan out
      for(let i=-10; i<=10; i++) {
           ctx.moveTo(w/2 + i * 20, horizonY);
           ctx.lineTo(w/2 + i * 150, h);
      }
      ctx.stroke();
  };

  const drawScope = (ctx: CanvasRenderingContext2D, w: number, h: number, data: Uint8Array, len: number) => {
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#10b981'; // Green Scope
      ctx.shadowBlur = 5;
      ctx.shadowColor = '#10b981';

      ctx.beginPath();
      const sliceWidth = w / len;
      let x = 0;
      for(let i = 0; i < len; i++) {
          const v = data[i] / 128.0;
          const y = (v * h/2);
          if(i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
          x += sliceWidth;
      }
      ctx.lineTo(w, h/2);
      ctx.stroke();
      
      // Grid overlay
      ctx.shadowBlur = 0;
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.2)';
      ctx.lineWidth = 1;
      // Grid lines code...
      ctx.beginPath();
      for(let i=0; i<w; i+=50) { ctx.moveTo(i, 0); ctx.lineTo(i, h); }
      for(let i=0; i<h; i+=50) { ctx.moveTo(0, i); ctx.lineTo(w, i); }
      ctx.stroke();
  };

  const drawHex = (ctx: CanvasRenderingContext2D, w: number, h: number, data: Uint8Array, len: number) => {
      const cx = w/2;
      const cy = h/2;
      const bass = getAverageVolume(data, 1, 6);
      const r = 50 + (bass / 255) * 50;
      
      const time = Date.now() * 0.001;
      
      ctx.strokeStyle = '#06b6d4'; // Cyan
      ctx.lineWidth = 2;
      
      // Draw spinning hexagon sphere logic
      const layers = 5;
      for(let j=0; j<layers; j++) {
          const layerR = r * (0.5 + j * 0.3);
          ctx.beginPath();
          for(let i=0; i<=6; i++) {
              const angle = (i / 6) * Math.PI * 2 + time * (j % 2 === 0 ? 1 : -1);
              const x = cx + Math.cos(angle) * layerR;
              const y = cy + Math.sin(angle) * layerR;
              if (i === 0) ctx.moveTo(x, y);
              else ctx.lineTo(x, y);
          }
          ctx.closePath();
          ctx.stroke();
      }
      
      // Center Pulse
      ctx.fillStyle = `rgba(6, 182, 212, ${bass/255})`;
      ctx.beginPath();
      ctx.arc(cx, cy, r * 0.3, 0, Math.PI*2);
      ctx.fill();
  };

  const drawFire = (ctx: CanvasRenderingContext2D, w: number, h: number, data: Uint8Array, len: number) => {
      const barCount = 64;
      const barWidth = w / barCount;
      const step = Math.floor(len / 2 / barCount);
      
      for(let i=0; i<barCount; i++) {
          const val = data[i * step];
          const height = (val / 255) * h;
          
          // Fire Gradient
          const g = ctx.createLinearGradient(0, h - height, 0, h);
          g.addColorStop(0, '#ef4444'); // Red Top
          g.addColorStop(0.5, '#f97316'); // Orange
          g.addColorStop(1, '#fde047'); // Yellow Base
          
          ctx.fillStyle = g;
          ctx.fillRect(i * barWidth, h - height, barWidth + 1, height);
          
          // Sparks
          if (val > 150 && Math.random() > 0.8) {
              ctx.fillStyle = '#ffffff';
              ctx.fillRect(i * barWidth + Math.random()*barWidth, h - height - Math.random()*20, 2, 2);
          }
      }
  };

  // --- Standard Player Logic ---

  useEffect(() => {
    setIsPlaying(false);
    setProgress(0);
    if(audioRef.current) {
        audioRef.current.currentTime = 0;
    }
  }, [src]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setProgress(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setProgress(time);
    }
  };
  
  const handleEnded = () => {
      setIsPlaying(false);
      setProgress(0);
      cancelAnimationFrame(animationRef.current!);
  }

  const formatTime = (seconds: number) => {
    if (!seconds) return "00:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full bg-zinc-950/80 border border-zinc-800/50 rounded-lg p-3 flex flex-col gap-3">
      <audio
        ref={audioRef}
        src={src}
        crossOrigin="anonymous"
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={handleEnded}
      />
      
      {/* Rack Mount Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-2 border-dashed">
         <div className="flex items-center gap-2">
             <Activity size={12} className={isPlaying ? "text-amber-500 animate-pulse" : "text-zinc-600"} />
             <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">{statusLabel}</span>
         </div>
         <button 
            onClick={onRemove}
            className="text-zinc-600 hover:text-red-400 transition-colors"
         >
            <X size={12} />
         </button>
      </div>

      <div className="flex items-center gap-3">
        {/* File Info */}
        <div className="w-8 h-8 rounded bg-zinc-900 border border-zinc-800 flex items-center justify-center shrink-0 shadow-inner">
            <Music size={14} className="text-amber-600" />
        </div>
        
        <div className="flex-1 min-w-0">
             <h4 className="text-xs font-bold text-zinc-300 truncate font-mono">{fileName}</h4>
             <div className="flex items-center gap-2 mt-1">
                 <button onClick={togglePlay} className="text-zinc-400 hover:text-white">
                     {isPlaying ? <Pause size={12} fill="currentColor"/> : <Play size={12} fill="currentColor"/>}
                 </button>
                 {/* Custom Scrubber */}
                 <div className="flex-1 h-1 bg-zinc-800 rounded-full relative group cursor-pointer shadow-inner">
                     <div className="absolute inset-0 rounded-full bg-amber-600 shadow-[0_0_8px_rgba(245,158,11,0.5)]" style={{width: `${(progress/duration)*100}%`}}></div>
                     <input
                        type="range"
                        min="0"
                        max={duration || 100}
                        value={progress}
                        onChange={handleSeek}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                 </div>
                 <span className="text-[9px] font-mono text-zinc-500">{formatTime(progress)}</span>
             </div>
        </div>
      </div>
      
      {/* VISUALIZER SCREEN (Moved to bottom and resized) */}
      <div className="relative w-full h-64 bg-black rounded border border-zinc-800 overflow-hidden group shadow-inner">
          <canvas 
            ref={canvasRef} 
            width={600} 
            height={300} 
            className="w-full h-full object-cover opacity-90"
          />
          {/* Visualizer Selector Overlay */}
          <div className="absolute top-2 right-2 z-10">
               <div className="relative group/select">
                  <select 
                    value={visualMode}
                    onChange={(e) => setVisualMode(e.target.value as VisualizerMode)}
                    className="appearance-none bg-black/60 backdrop-blur border border-zinc-700 text-zinc-300 text-[10px] font-bold uppercase rounded pl-2 pr-6 py-1 outline-none focus:border-amber-500 hover:bg-black/80 cursor-pointer transition-colors font-mono"
                  >
                      {(Object.keys(t.visModes) as VisualizerMode[]).map((mode) => (
                          <option key={mode} value={mode}>{t.visModes[mode]}</option>
                      ))}
                  </select>
                  <ChevronDown size={10} className="absolute right-2 top-1.5 text-zinc-500 pointer-events-none"/>
               </div>
          </div>
          <div className="absolute bottom-2 left-2 text-[9px] font-mono text-zinc-500 uppercase bg-black/50 px-1 rounded pointer-events-none border border-zinc-800/50">
              ENG :: {visualMode.toUpperCase()}
          </div>
      </div>
    </div>
  );
};

export default AudioPlayer;
